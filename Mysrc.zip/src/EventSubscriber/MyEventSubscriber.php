<?php
// src/EventSubscriber/GlobalChangeLogSubscriber.php

namespace App\EventSubscriber;

use App\Entity\ChangeLog;
use Doctrine\Common\EventSubscriber;
use Doctrine\ORM\Events;
use Doctrine\Persistence\Event\LifecycleEventArgs;
use Symfony\Component\Security\Core\Security;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\ORM\UnitOfWork;

class GlobalChangeLogSubscriber implements EventSubscriber
{
    private $security;
    private $entityManager;
    private $excludedEntities = ['App\Entity\ChangeLog']; // Add entities to exclude

    public function __construct(Security $security, EntityManagerInterface $entityManager)
    {
        $this->security = $security;
        $this->entityManager = $entityManager;
    }

    public function getSubscribedEvents()
    {
        return [
            Events::postPersist,
            Events::preUpdate,
            Events::preRemove,
        ];
    }

    public function postPersist(LifecycleEventArgs $args)
    {
        $entity = $args->getObject();
        if ($this->shouldLogEntity($entity)) {
            $this->logActivity($entity, 'insert', null, $this->serializeEntity($entity));
        }
    }

    public function preUpdate(LifecycleEventArgs $args)
    {
        $entity = $args->getObject();
        if ($this->shouldLogEntity($entity)) {
            $unitOfWork = $this->entityManager->getUnitOfWork();
            $unitOfWork->computeChangeSets();
            
            // Get the original data before changes
            $originalData = $this->getOriginalEntityData($entity, $unitOfWork);
            
            // Get the changes
            $changeSet = $unitOfWork->getEntityChangeSet($entity);
            
            $this->logActivity(
                $entity, 
                'update', 
                json_encode($originalData), 
                json_encode($this->getCurrentEntityData($entity, $changeSet))
            );
        }
    }

    public function preRemove(LifecycleEventArgs $args)
    {
        $entity = $args->getObject();
        if ($this->shouldLogEntity($entity)) {
            $this->logActivity(
                $entity, 
                'delete', 
                $this->serializeEntity($entity), 
                null
            );
        }
    }

    private function shouldLogEntity($entity)
    {
        $className = get_class($entity);
        // Skip logging for excluded entities
        return !in_array($className, $this->excludedEntities);
    }

    private function getOriginalEntityData($entity, UnitOfWork $unitOfWork)
    {
        $classMetadata = $this->entityManager->getClassMetadata(get_class($entity));
        $originalData = [];
        
        foreach ($classMetadata->getFieldNames() as $fieldName) {
            $originalData[$fieldName] = $this->getOriginalFieldValue($entity, $fieldName, $unitOfWork);
        }
        
        return $originalData;
    }

    private function getOriginalFieldValue($entity, $fieldName, UnitOfWork $unitOfWork)
    {
        $changeSet = $unitOfWork->getEntityChangeSet($entity);
        
        if (isset($changeSet[$fieldName])) {
            return $changeSet[$fieldName][0]; // Original value
        }
        
        // If field is not in changeset, get current value
        $getter = 'get' . ucfirst($fieldName);
        if (method_exists($entity, $getter)) {
            return $entity->$getter();
        }
        
        return null;
    }

    private function getCurrentEntityData($entity, array $changeSet)
    {
        $classMetadata = $this->entityManager->getClassMetadata(get_class($entity));
        $currentData = [];
        
        foreach ($classMetadata->getFieldNames() as $fieldName) {
            $getter = 'get' . ucfirst($fieldName);
            if (method_exists($entity, $getter)) {
                $value = $entity->$getter();
                if (is_object($value) && method_exists($value, 'getId')) {
                    $currentData[$fieldName] = $value->getId();
                } else {
                    $currentData[$fieldName] = $value;
                }
            }
        }
        
        return $currentData;
    }

    private function serializeEntity($entity)
    {
        try {
            $data = [];
            $classMetadata = $this->entityManager->getClassMetadata(get_class($entity));
            
            foreach ($classMetadata->getFieldNames() as $fieldName) {
                $getter = 'get' . ucfirst($fieldName);
                if (method_exists($entity, $getter)) {
                    $value = $entity->$getter();
                    // Handle DateTime objects
                    if ($value instanceof \DateTime) {
                        $data[$fieldName] = $value->format('Y-m-d H:i:s');
                    } 
                    // Handle entity references
                    elseif (is_object($value) && method_exists($value, 'getId')) {
                        $data[$fieldName] = $value->getId();
                    } else {
                        $data[$fieldName] = $value;
                    }
                }
            }
            
            return json_encode($data);
        } catch (\Exception $e) {
            // Fallback with just the ID if serialization fails
            return json_encode(['id' => $entity->getId()]);
        }
    }

    private function logActivity($entity, $action, $oldData, $newData)
    {
        try {

            $className = get_class($entity);
            $tableName = $this->entityManager->getClassMetadata($className)->getTableName();
            
            // Use direct connection to avoid recursive loops
            $conn = $this->entityManager->getConnection();
            
            $conn->executeStatement(
                'INSERT INTO change_log (table_name, record_id, action, changed_at, user_id, old_data, new_data) VALUES (?, ?, ?, ?, ?, ?, ?)',
                [
                    $tableName,
                    method_exists($entity, 'getId') ? $entity->getId() : null,
                    $action,
                    (new \DateTime())->format('Y-m-d H:i:s'),
                    0,
                    $oldData,
                    $newData
                ]
            );
        } catch (\Exception $e) {
            // Log error but don't interrupt the main operation
            error_log('Error logging change: ' . $e->getMessage());
        }
    }
}