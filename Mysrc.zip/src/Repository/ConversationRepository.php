<?php

namespace App\Repository;

use App\Entity\Conversation;
use App\Entity\ConversationMessage;
use App\Entity\DebiDoss;
use App\Entity\Debiteur;
use App\Entity\Dossier;
use App\Entity\QueueDepartement;
use App\Entity\Teams;
use App\Entity\Telephone;
use App\Entity\Utilisateurs;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;
use Doctrine\DBAL\Connection;
use Doctrine\ORM\EntityManagerInterface;
use Psr\Log\LoggerInterface;

/**
 * @extends ServiceEntityRepository<Conversation>
 *
 * @method Conversation|null find($id, $lockMode = null, $lockVersion = null)
 * @method Conversation|null findOneBy(array $criteria, array $orderBy = null)
 * @method Conversation[]    findAll()
 * @method Conversation[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class ConversationRepository extends ServiceEntityRepository
{

    public $em;
    private $conn;
    public $logger;
    public function __construct(ManagerRegistry $registry,EntityManagerInterface $em,Connection $conn,LoggerInterface $logger)
    {
        parent::__construct($registry, Conversation::class);
        $this->em = $em;
        $this->conn = $conn;
        $this->logger = $logger;

    }

    public function createConversation($contenu,$idDebiteur,$type,$userAffecte,$idUser, $idDossier, $idTelephone){

        $date=new \DateTime();

        $debiteur = $this->getDebiteur($idDebiteur);
        $userAffecte = $this->getUser($userAffecte);
        $user = $this->getUser($idUser);

        $dossier = $this->getDossier($idDossier);
        $telephone = $this->getTelephone($idTelephone);

        $conversation  = new Conversation();
        $conversation->setIdCreateur($user);
        $conversation->setIdUserAffecte($userAffecte);
        $conversation->setIdDebiteur($debiteur);
        $conversation->setDateCreation($date);
        $conversation->setEtat(0);
        $conversation->setType($type);
        $conversation->setIdDossier($dossier);
        $conversation->setIdTelephone($telephone);
        // Generate random 12-character alphanumeric string
        $randomString = substr(str_shuffle('0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'), 0, 12);
        // Set conversation number with 'con-' prefix
        $conversation->setNumero('con-' . $randomString);

        $this->em->persist($conversation);
        $this->em->flush();

        $message  = new ConversationMessage();
        $message->setContenu($contenu);
        $message->setDate($date);
        $message->setExpiteur(0);
        $message->setIdConversation($conversation);
        $this->em->persist($message);

        $this->em->flush();
        return $conversation;
    }

    public function getConversationEnCours($idUser) {
        $sql = "SELECT c.*, d.nom AS debiteur_nom, d.prenom AS debiteur_prenom, t.numero AS telephone_numero
                FROM conversation c
                LEFT JOIN debiteur d ON c.id_debiteur_id = d.id
                LEFT JOIN telephone t ON c.id_telephone_id = t.id
                WHERE c.etat != 2 AND (c.id_user_affecte_id = :idUser OR c.id_user_affecte_id IS NULL)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bindValue('idUser', $idUser);
        $stmt = $stmt->executeQuery();
        return $stmt->fetchAllAssociative();
    }
    
    public function getMessagesForConversation($conversationId)
    {
        $sql = "SELECT m.* 
                FROM conversation_message m
                WHERE m.id_conversation_id = :conversationId";
        $stmt = $this->conn->prepare($sql);
        $stmt->bindValue('conversationId', $conversationId);
        $stmt = $stmt->executeQuery();
        $resulat = $stmt->fetchAllAssociative();
        return $resulat;
    }

    public function sendMessage($messageContent, $conversation)
    {
        $date = new \DateTime();

        $message = new ConversationMessage();
        $message->setContenu($messageContent);
        $message->setDate($date);
        $message->setExpiteur(0); // Assuming 0 is the default sender

        $message->setIdConversation($conversation);

        $this->em->persist($message);
        $this->em->flush();

        $conversation  = $this->em->getRepository(Conversation::class)->find($conversation);
        if($conversation)
        {
            $countMyMessages  = $this->em->getRepository(ConversationMessage::class)->findBy(  ["idConversation" => $conversation->getId(), "expiteur" => "0"]);
            
            if(count($countMyMessages) == 2)
            {
                $conversation->setDateDebut($date);
                $firstClientMessage = $this->em->getRepository(ConversationMessage::class)
                    ->findOneBy(
                        ["idConversation" => $conversation->getId(), "expiteur" => "1"],
                        ["date" => "ASC"]
                    );
                
                if ($firstClientMessage) {
                    // Calculate time difference in seconds
                    $firstMessageDate = $firstClientMessage->getDate();
                    $timeNow = new \DateTime();
                    $timeDiff = $timeNow->getTimestamp() - $firstMessageDate->getTimestamp();
                    
                    $conversation->setFirstReply($timeDiff);
                }
            

            }
            else
            {
                $lastClientMessage = $this->em->getRepository(ConversationMessage::class)
                ->findOneBy(
                    ["idConversation" => $conversation->getId(), "expiteur" => "1"],
                    ["date" => "DESC"]
                );
            
                if ($lastClientMessage) {
                    $lastMessageDate = $lastClientMessage->getDate();
                    $timeNow = new \DateTime();
                    $currentDiff = $timeNow->getTimestamp() - $lastMessageDate->getTimestamp();
                    
                    $existingReply = $conversation->getReply();
                    if ($existingReply === null) {
                        $conversation->setReply($currentDiff);
                    } else {
                        // Calculate average reply time
                        $previousCount = count($countMyMessages) - 2;
                        $newAverage = (($existingReply * $previousCount) + $currentDiff) / ($previousCount + 1);
                        $conversation->setReply($newAverage);
                    }
                }
        
            }
            $this->em->flush();

    
        }


        return $message;
    }

    public function endConversation($id)
    {
        $date = new \DateTime();
        $conversation  = $this->em->getRepository(Conversation::class)->find($id);

        $conversation->setDateFin($date);
        $conversation->setEtat(2);


        if ($conversation->getDateDebut()) {
            // Calculate time difference in seconds
            $dateDebut = $conversation->getDateDebut();
            $timeNow = new \DateTime();
            $timeDiff = $timeNow->getTimestamp() - $dateDebut->getTimestamp();
            
            $conversation->setTimeToEnd($timeDiff);
        }


        $this->em->flush();

        return true;
    }

    public function updateMessageDateFinAttente($messageId)
    {
        $date = new \DateTime();

        $message = $this->em->getRepository(ConversationMessage::class)->find($messageId);
        if ($message) {
            $message->setDateFinAttente($date);
            $this->em->flush();
        }
    }

    public function getMyStatistique($idUser)
    {
        $sql = "SELECT 
                    AVG(c.first_reply) AS avg_first_reply, 
                    AVG(c.reply) AS avg_reply, 
                    AVG(c.time_to_end) AS avg_time_to_end
                FROM conversation c
                WHERE c.id_user_affecte_id = :idUser";
        $stmt = $this->conn->prepare($sql);
        $stmt->bindValue('idUser', $idUser);
        $stmt = $stmt->executeQuery();
        $result = $stmt->fetchAssociative();
        return $result;
    }


    public function getConversationByDossier($dossier)
    {
        $sql = "SELECT c.*, u.nom AS user_nom, u.prenom AS user_prenom
                FROM conversation c
                JOIN utilisateurs u ON c.id_user_affecte_id = u.id
                WHERE c.id_dossier_id = :dossier";
        $stmt = $this->conn->prepare($sql);
        $stmt->bindValue('dossier', $dossier);
        $stmt = $stmt->executeQuery();
        $resulat = $stmt->fetchAllAssociative();
        return $resulat;
    }

    public function getOneConversation($id)
    {
        $sql = "SELECT c.*, u.nom AS user_nom, u.prenom AS user_prenom, d.nom AS debiteur_nom, d.prenom AS debiteur_prenom
                FROM conversation c
                JOIN utilisateurs u ON c.id_user_affecte_id = u.id
                JOIN debiteur d ON c.id_debiteur_id = d.id
                WHERE c.id = :id";
        $stmt = $this->conn->prepare($sql);
        $stmt->bindValue('id', $id);
        $stmt = $stmt->executeQuery();
        $result = $stmt->fetchAssociative();
        return $result;
    }

    public function pushMessage($contenu,$idDebiteur,$type,$userAffecte,$idUser, $idDossier, $Telephone,$conversation){

        $date=new \DateTime();


        $conversation = $this->em->getRepository(Conversation::class)->find($conversation);

        if($conversation == null)
        {
            $conversation  = new Conversation();
            $conversation->setDateCreation($date);
            $conversation->setEtat(0);
            $conversation->setType($type);
            // Generate random 12-character alphanumeric string
            $randomString = substr(str_shuffle('0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'), 0, 12);
            // Set conversation number with 'con-' prefix
            $conversation->setNumero('con-' . $randomString);
            $conversation->setNumeroTelephone($Telephone);

            $this->em->persist($conversation);
            $this->em->flush();

        }

        $message  = new ConversationMessage();
        $message->setContenu($contenu);
        $message->setDate($date);
        $message->setExpiteur(0);
        $message->setIdConversation($conversation);
        $this->em->persist($message);

        $this->em->flush();
        return $conversation;
    }


    public function matchConversation($idDossier, $idConversation)
    {
        $date = new \DateTime();
        $conversation  = $this->em->getRepository(Conversation::class)->find($idConversation);
        $dossier  = $this->em->getRepository(Dossier::class)->find($idDossier);

        if ($conversation == null || $dossier == null) {
           
            return "Erreur: Conversation ou Dossier introuvable.";
        }

        $conversation->setIdDossier($dossier);
        $doss = $this->em->getRepository(DebiDoss::class)->findBy(array("id_dossier"=>$idDossier));

        $numeroSansZero = ltrim($conversation->getNumeroTelephone(), '0');
        $numeroAvecZero = str_starts_with($conversation->getNumeroTelephone(), '0') ? $conversation->getNumeroTelephone() : '0' . $numeroSansZero;

        foreach ($doss as $dos) {
            $debiteur = $this->em->getRepository(Debiteur::class)->find($dos->getIdDebiteur());
            
            // Try with numeroAvecZero
            $telephone = $this->em->getRepository(Telephone::class)->findOneBy([
                'numero' => $numeroAvecZero,
                'id_debiteur' => $debiteur
            ]);

            // If not found, try with numeroSansZero
            if (!$telephone && $numeroAvecZero !== $numeroSansZero) {
                $telephone = $this->em->getRepository(Telephone::class)->findOneBy([
                    'numero' => $numeroSansZero,
                    'id_debiteur' => $debiteur
                ]);
            }

            if ($telephone) {
                $conversation->setIdTelephone($telephone);
                $conversation->setIdDebiteur($debiteur);
                break;
            }
        }
      
        $this->em->flush();

        return true;
    }


    public function assingUser($idUser, $idConversation)
    {
        $user = $this->getUser($idUser);
        $conversation  = $this->em->getRepository(Conversation::class)->find($idConversation);
        if ($conversation != null && $user != null) {
            $conversation->setIdUserAffecte($user);
            $this->em->flush();
        }
    }

    public function assingTeam($idTeam, $idQueue)
    {
        $team = $this->getTeam($idTeam);
        $conversation  = $this->em->getRepository(QueueDepartement::class)->find($idQueue);
        if ($conversation != null && $team != null) {
            $conversation->setTeam($team);
            $this->em->flush();
        }
    }

    public function getQueueDepartement(int $idUser): array
    {
        $sql = "
            SELECT 
                c.*, 
                qd.*, 
                dtr.nom AS debiteur_nom,
                dtr.prenom AS debiteur_prenom
            FROM conversation c
            JOIN queue_departement qd ON qd.conversation_id = c.id
            LEFT JOIN debiteur dtr ON dtr.id = c.id_debiteur_id
            WHERE qd.departement_id IN (
                SELECT d.id
                FROM departement d
                WHERE d.manager_id = :idUser
            )
            OR qd.team_id IN (
                SELECT t.id
                FROM teams t
                WHERE t.manager_id = :idUser
            )
        ";
    
        $stmt = $this->conn->prepare($sql);
        $stmt->bindValue('idUser', $idUser);
        $result = $stmt->executeQuery();
    
        return $result->fetchAllAssociative();
    }

    public function getDepartementEquipe(int $idUser): array
    {
        $sql = "
            SELECT * FROM teams 
            WHERE id_departement_id IN (
                SELECT id FROM departement WHERE manager_id = :idUser
            )
        ";
    
        $stmt = $this->conn->prepare($sql);
        $stmt->bindValue('idUser', $idUser);
        $result = $stmt->executeQuery();
    
        return $result->fetchAllAssociative();
    }

    public function getUsersOfDepartementTeams(int $idUser): array
    {
        $sql = "
            SELECT u.* FROM utilisateurs u
            WHERE u.teams_id IN (
                SELECT t.id FROM teams t
                WHERE t.id_departement_id IN (
                    SELECT d.id FROM departement d WHERE d.manager_id = :idUser
                )
            )
        ";

        $stmt = $this->conn->prepare($sql);
        $stmt->bindValue('idUser', $idUser);
        $result = $stmt->executeQuery();

        return $result->fetchAllAssociative();
    }

        

    public function getUser($id){
        $entity  = $this->em->getRepository(Utilisateurs::class)->find($id);
        return $entity;
    }

    public function getDebiteur($id){
        $entity  = $this->em->getRepository(Debiteur::class)->find($id);
        return $entity;
    }

    public function getDossier($id){
        $entity  = $this->em->getRepository(Dossier::class)->find($id);
        return $entity;
    }

    public function getTelephone($id){
        $entity  = $this->em->getRepository(Telephone::class)->find($id);
        return $entity;
    }


    public function getTelephoneByNumero($numero){
        $entity  = $this->em->getRepository(Telephone::class)->findBy(array("numero" => $numero));
        return $entity;
    }

    public function getTeam($id){
        $entity  = $this->em->getRepository(Teams::class)->find($id);
        return $entity;
    }
    

}
