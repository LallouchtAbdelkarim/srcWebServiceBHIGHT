<?php

namespace App\Repository;

use App\Entity\Dossier;
use App\Entity\NoteDossier;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;
use Doctrine\DBAL\Connection;

/**
 * @extends ServiceEntityRepository<Dossier>
 *
 * @method Dossier|null find($id, $lockMode = null, $lockVersion = null)
 * @method Dossier|null findOneBy(array $criteria, array $orderBy = null)
 * @method Dossier[]    findAll()
 * @method Dossier[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class DossierRepository extends ServiceEntityRepository
{

    private $conn;
    public function __construct(ManagerRegistry $registry,Connection $conn)
    {
        parent::__construct($registry, Dossier::class);
        $this->conn = $conn;
    }

    public function save(Dossier $entity, bool $flush = false): void
    {
        $this->getEntityManager()->persist($entity);

        if ($flush) {
            $this->getEntityManager()->flush();
        }
    }

    public function remove(Dossier $entity, bool $flush = false): void
    {
        $this->getEntityManager()->remove($entity);

        if ($flush) {
            $this->getEntityManager()->flush();
        }
    }
    public function createNoteDossier($id,$note): void
    {
        $dossier = $this->getEntityManager()->getRepository(Dossier::class)->findOneBy(['id' => $id]);
        $integration = new NoteDossier();
        $integration->setNote($note);
        $integration->setIdDossier($dossier);
        $this->em->persist($integration);
        $this->em->flush();
    }

    public function UpdateGestDossier($id, $timer, $from)
    {
        if ($from == 1) {
            $sqlUpdateDossier = "
                UPDATE dossier
                SET date_fin_prevesionnel = NOW()
                WHERE id = :id
            ";

            $stmtUpdate = $this->conn->prepare($sqlUpdateDossier);
            $stmtUpdate->bindParam(':id', $id);
            $stmtUpdate->execute();
            
        }
    
        // Insert into HistoriqueTimer table
        $sqlInsertHistorique = "
            INSERT INTO historique_timer (id_dossier_id , timer, date)
            VALUES (:id, :timer, NOW())
        ";
    
        $stmtInsert = $this->conn->prepare($sqlInsertHistorique);
        $stmtInsert->bindParam(':id', $id);
        $stmtInsert->bindParam(':timer', $timer);
        $stmtInsert->execute();
    }


    public function getNextDossier($userLogin)
    {
        $sql = "
            SELECT * 
            FROM dossier d
            WHERE d.date_fin IS NULL 
            AND d.id_user_assign_id = :userLogin 
            AND NOT EXISTS (
                SELECT 1 
                FROM historique_timer ht 
                WHERE ht.id_dossier_id = d.id 
                AND DATE(ht.date) = CURDATE()
            )
            ORDER BY d.date_fin_prevesionnel ASC 
            LIMIT 1
        ";        
        $stmt = $this->conn->prepare($sql);
        $stmt->bindParam(':userLogin', $userLogin);
        $stmt = $stmt->executeQuery();
        $resultat = $stmt->fetchAll();
        return $resultat;
    }

    public function getQueueNextDossier()
    {
        $sql = "
            SELECT * 
            FROM dossier d
            WHERE d.date_fin IS NULL  
            AND d.id IN (
                SELECT qs.dossier_id 
                FROM queue_segmentation qs 
                WHERE qs.etat = 0
            )
            AND NOT EXISTS (
                SELECT 1 
                FROM historique_timer ht 
                WHERE ht.id_dossier_id = d.id 
                AND DATE(ht.date) = CURDATE()
            )
            ORDER BY d.date_fin_prevesionnel ASC 
            LIMIT 1
        ";        
        $stmt = $this->conn->prepare($sql);
        $stmt = $stmt->executeQuery();
        $resultat = $stmt->fetchAll();
        return $resultat;
    }

    
    public function insertQueueSegmentation(): void
    {
        // First, truncate the table (delete all rows)
        $truncateSql = "TRUNCATE TABLE queue_segmentation";
        $this->conn->executeStatement($truncateSql); 

        $sql = "
            INSERT INTO queue_segmentation (dossier_id, segmentation_id, etat, type)
            SELECT 
                sd.id_dossier,
                MIN(sd.id_seg), 
                0,
                (
                    SELECT s.type 
                    FROM segmentation s 
                    WHERE s.id = MIN(sd.id_seg)
                    LIMIT 1
                )
            FROM debt_force_seg.seg_dossier sd
            WHERE 
                sd.id_seg IN (
                    SELECT s.id 
                    FROM segmentation s 
                    WHERE s.id_status_id = 3
                )
                AND sd.id_dossier IN (
                    SELECT d.id 
                    FROM dossier d 
                    WHERE EXISTS (
                        SELECT 1 
                        FROM creance c 
                        WHERE c.id_dossier_id = d.id 
                        AND c.etat = -1
                    )
                )
                AND sd.id_dossier NOT IN (
                    SELECT qs.dossier_id FROM queue_segmentation qs
                )
            GROUP BY sd.id_dossier
        ";
    
        $stmt = $this->conn->prepare($sql);
        $stmt->executeQuery();
    }
      
    
    public function insertQueueAgent($dossier, $user, $etat, $description, $date): void
    {
        $sql = "
            INSERT INTO queue_agent (dossier_id, user_id, etat, description, date)
            VALUES (:dossier_id, :user_id, :etat, :description, :date)
        ";
    
        $stmt = $this->conn->prepare($sql);
        $stmt->executeQuery([
            'dossier_id' => $dossier,
            'user_id' => $user,
            'etat' => $etat,
            'description' => $description,
            'date' => $date,
        ]);
    }
    

    public function insertQueueAgentCron(): void
    {
        $today = (new \DateTime())->format('Y-m-d');
    
        // Insertion des tâches du jour
        $sqlTask = "
            INSERT INTO queue_agent (dossier_id, user_id, etat, description, date)
            SELECT 
                c.id_dossier_id AS dossier_id,
                t.assigned_user_id AS user_id,
                0 AS etat,
                'tache d''aujourd''hui' AS description,
                t.time AS date
            FROM task t
            INNER JOIN creance c ON t.id_creance_id = c.id
            WHERE DATE(t.date_echeance) = :today
        ";
        $stmtTask = $this->conn->prepare($sqlTask);
        $stmtTask->executeQuery(['today' => $today]);
    
        // Insertion à partir des conversations
        $sqlConv = "
            INSERT INTO queue_agent (dossier_id, user_id, etat, description, date)
            SELECT 
                conversation.id_dossier_id,
                conversation.id_user_affecte_id,
                0,
                'à partir d''une conversation',
                NULL
            FROM conversation
            WHERE conversation.etat = 1
            AND conversation.id_user_affecte_id IS NOT NULL
            AND conversation.id_dossier_id IS NOT NULL
        ";
        $stmtConv = $this->conn->prepare($sqlConv);
        $stmtConv->executeQuery();
    }
    

    public function insertQueueDepartement($dossier, $departement, $etat, $convertation): void
    {
        $sql = "
            INSERT INTO queue_departement (dossier_id, departement_id, etat, team_id, conversation_id)
            VALUES (:dossier_id, :departement, :etat, :team, :convertation)
        ";
    
        $stmt = $this->conn->prepare($sql);
        $stmt->executeQuery([
            'dossier_id' => $dossier,
            'user_id' => $departement,
            'etat' => $etat,
            'team' => null,
            'convertation' => $convertation,
        ]);
    }
}
