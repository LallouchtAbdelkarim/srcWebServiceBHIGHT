<?php

namespace App\Controller\OmniChannel;

use App\Entity\Message;
use App\Entity\DetailMessage;
use App\Entity\Utilisateurs;
use App\Repository\ConversationRepository;
use App\Repository\DossierRepository;
use App\Repository\Statistiques\statistiquesRepo;
use App\Service\MessageService;
use App\Service\AuthService;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Session\Session;
use Doctrine\DBAL\Connection;
use Symfony\Component\Mailer\MailerInterface;
use Symfony\Component\Mime\Email;

use Symfony\Component\Serializer\SerializerInterface;
use Lexik\Bundle\JWTAuthenticationBundle\Encoder\JWTEncoderInterface;

#[Route('/API/omnichannel') ]

class OmniChannelController extends AbstractController
{
    private $MessageService;
    private $entityManager;
    private $JWTManager;
    private $AuthService;
    private $conn;
    public function __construct(Connection $connection,  
    MessageService $MessageService
    ,JWTEncoderInterface $JWTManager,
    EntityManagerInterface $entityManager,
    AuthService $AuthService,
    )
    {
         $this->JWTManager = $JWTManager;
         $this->MessageService = $MessageService;
         $this->entityManager = $entityManager;
         $this->AuthService = $AuthService;
         $this->connection = $connection;
    }


    #[Route('/insertConversation/', name: 'insertConversation')]
    public function insertConversation(Request $request, ConversationRepository $conversationRepo,DossierRepository $dossierRepository): Response
    {
        $codeStatut = "ERROR";
        try {
            $respObjects = array();
            $codeStatut = "ERROR";
            try {
                $this->AuthService->checkAuth(0, $request);
                $idUser = $this->AuthService->returnUserId($request);
                $data = json_decode($request->getContent(), true);

                $userAffecte = $idUser;
                $subTemplate = $data["subTemplate"];
                $type = 0;
                if ($subTemplate == 'Viber') {
                    $type = 1;
                } elseif ($subTemplate == 'Sms') {
                    $type = 2;
                } elseif ($subTemplate == 'Whatsapp') {
                    $type = 3;
                } elseif ($subTemplate == 'Messenger') {
                    $type = 4;
                }
                $idDebiteur = $data["selectedDebiteur"]['id'];
                $message = $data["template"]['message'];
                $idDossier = $data["idDossier"];
                $telephones = $data["telephones"];

                foreach ($telephones as $telephone) {

                    $conversationRepo->createConversation(
                        $message, 
                        $idDebiteur, 
                        $type, 
                        $userAffecte, 
                        $idUser,
                        $idDossier,
                        $telephone['id']
                    );

                    $dossierRepository->insertQueueAgent($idDossier, $userAffecte, 0, "Conversation ouverte", new \DateTime());
                }

                $respObjects["data"] = "OK";
                $codeStatut = "OK";
            } catch (\Exception $e) {
                $codeStatut = "ERROR";
                $respObjects["err"] = $e->getMessage();
            }
            $respObjects["codeStatut"] = $codeStatut;
            $respObjects["message"] = $this->MessageService->checkMessage($codeStatut);
            return $this->json($respObjects);
        } catch (\Exception $th) {
            $codeStatut = $th->getMessage();
        }

        $respObjects["codeStatut"] = $codeStatut;
        $respObjects["message"] = $this->MessageService->checkMessage($codeStatut);
        return $this->json($respObjects);
    }


    #[Route('/getConversationEnCours',methods:"GET")]
    public function checkCreanceExist(Request $request,ConversationRepository $conversationRepo): JsonResponse
    {
        $respObjects =array();
        $codeStatut="ERROR";
        try{

            $this->AuthService->checkAuth(0,$request);  

            $idUser = $this->AuthService->returnUserId($request);

            $conversations = $conversationRepo->getConversationEnCours($idUser);
            if($conversations){
                $respObjects["data"] = $conversations;

                $statistiques = $conversationRepo->getMyStatistique($idUser);
                if($statistiques){
                    $respObjects["statistiques"] = $statistiques;
                }
                $codeStatut="OK";
            }else{
                $codeStatut = "NOT_EXIST_ELEMENT";
            }
            
        }catch(\Exception $e){
            $codeStatut="ERROR";
            $respObjects["err"] = $e->getMessage();
        }
        $respObjects["codeStatut"] = $codeStatut;
        $respObjects["message"] = $this->MessageService->checkMessage($codeStatut);
        return $this->json($respObjects);
    }

    #[Route('/getMessages', methods: ['GET'])]
    public function getMessagesForConversation(Request $request, ConversationRepository $conversationRepo): JsonResponse
    {
        $respObjects = array();
        $codeStatut = "ERROR";
        try {
            $this->AuthService->checkAuth(0, $request);
            $id = $request->get("id");
            $messages = $conversationRepo->getMessagesForConversation($id);
            if ($messages) {
                $dateNow = new \DateTime();
                foreach ($messages as &$message) {
                    if ($message['date_fin_attente'] == null && $message['expiteur'] == 1) {
                        $conversationRepo->updateMessageDateFinAttente($message['id']);
                    }
                }
                $respObjects["data"] = $messages;
                $codeStatut = "OK";
            } else {
                $codeStatut = "NOT_EXIST_ELEMENT";
            }
        } catch (\Exception $e) {
            $codeStatut = "ERROR";
            $respObjects["err"] = $e->getMessage();
        }
        $respObjects["codeStatut"] = $codeStatut;
        $respObjects["message"] = $this->MessageService->checkMessage($codeStatut);
        return $this->json($respObjects);
    }


    #[Route('/sendMessage')]
    public function sendMessage(Request $request, ConversationRepository $conversationRepo): JsonResponse
    {
        $respObjects =array();
        $codeStatut = "ERROR";

        try {
            $this->AuthService->checkAuth(0,$request);
            $data = json_decode($request->getContent(), true);


            $conversation = $conversationRepo->find($data["conversation"]);
            if ($conversation) {
                $conversationRepo->sendMessage($data["message"],$conversation);

                $codeStatut = "OK";
            } else {
                $codeStatut = "NOT_EXIST_ELEMENT";
            }

        } catch (\Exception $e) {
            $codeStatut = "ERROR";
        }

        // Prepare the response
        $respObjects["codeStatut"] = $codeStatut;
        $respObjects["message"] = $this->MessageService->checkMessage($codeStatut);
        return $this->json($respObjects);
    }

    #[Route('/endMessage', methods: ['GET'])]
    public function endMessage(Request $request, ConversationRepository $conversationRepo): JsonResponse
    {
        $respObjects = array();
        $codeStatut = "ERROR";
        try {
            $this->AuthService->checkAuth(0, $request);
            $id = $request->get("id");
            $conversation = $conversationRepo->endConversation($id);
            if ($conversation) {
                $codeStatut = "OK";
            } else {
                $codeStatut = "ERROR";
            }
        } catch (\Exception $e) {
            $codeStatut = "ERROR";
            $respObjects["err"] = $e->getMessage();
        }
        $respObjects["codeStatut"] = $codeStatut;
        $respObjects["message"] = $this->MessageService->checkMessage($codeStatut);
        return $this->json($respObjects);
    }


    #[Route('/getConversationsByDossier',methods:"GET")]
    public function getConversationsByDossier(Request $request,ConversationRepository $conversationRepo): JsonResponse
    {
        $respObjects =array();
        $codeStatut="ERROR";
        try{

            $this->AuthService->checkAuth(0,$request);  

            $id = $request->get("id");

            $conversations = $conversationRepo->getConversationByDossier($id);
            if($conversations){
                $respObjects["data"] = $conversations;

                $codeStatut="OK";
            }else{
                $codeStatut = "NOT_EXIST_ELEMENT";
            }
            
        }catch(\Exception $e){
            $codeStatut="ERROR";
            $respObjects["err"] = $e->getMessage();
        }
        $respObjects["codeStatut"] = $codeStatut;
        $respObjects["message"] = $this->MessageService->checkMessage($codeStatut);
        return $this->json($respObjects);
    }


    #[Route('/getOneConversation', methods: ['GET'])]
    public function getOneConversation(Request $request, ConversationRepository $conversationRepo): JsonResponse
    {
        $respObjects = array();
        $codeStatut = "ERROR";
        try {
            $this->AuthService->checkAuth(0, $request);
            $id = $request->get("id");

            $conversation = $conversationRepo->getOneConversation($id);
            if ($conversation) {
                $respObjects["conversation"] = $conversation;
                $messages = $conversationRepo->getMessagesForConversation($id);
                if ($messages) {
                    foreach ($messages as &$message) {
                        if ($message['date_fin_attente'] == null && $message['expiteur'] == 1) {
                            $conversationRepo->updateMessageDateFinAttente($message['id']);
                        }
                    }
                    $respObjects["messages"] = $messages;
                }
                $codeStatut = "OK";
            } else {
                $codeStatut = "NOT_EXIST_ELEMENT";
            }
        } catch (\Exception $e) {
            $codeStatut = "ERROR";
            $respObjects["err"] = $e->getMessage();
        }
        $respObjects["codeStatut"] = $codeStatut;
        $respObjects["message"] = $this->MessageService->checkMessage($codeStatut);
        return $this->json($respObjects);
    }

    #[Route('/pushMessage/', name: 'pushMessage')]
    public function pushMessage(Request $request, ConversationRepository $conversationRepo,DossierRepository $dossierRepository): Response
    {
        $codeStatut = "ERROR";
        try {
            $respObjects = array();
            $codeStatut = "ERROR";
            try {
                $this->AuthService->checkAuth(0, $request);
                $idUser = $this->AuthService->returnUserId($request);
                $data = json_decode($request->getContent(), true);

                $userAffecte = $idUser;
                $subTemplate = $data["subTemplate"];
                $type = 0;
                if ($subTemplate == 'Viber') {
                    $type = 1;
                } elseif ($subTemplate == 'Sms') {
                    $type = 2;
                } elseif ($subTemplate == 'Whatsapp') {
                    $type = 3;
                } elseif ($subTemplate == 'Messenger') {
                    $type = 4;
                }
                $message = $data["template"]['message'];
                $telephone = $data["telephone"];
                $conversation = $data["conversation"];
                $departement = $data["departement"];

                if($conversation != null){
                    $conversationRepo->pushMessage(
                        $message, 
                        null, 
                        $type, 
                        $userAffecte, 
                        $idUser,
                        null,
                        $telephone,
                        $conversation
                    );

                    if($conversation->getIdDossier() != null && $conversation->getIdUserAffecte() != null)
                    {
                        $dossierRepository->insertQueueAgent($conversation->getIdDossier(), $conversation->getIdUserAffecte(), 0, "Message omniChannel envoyé", new \DateTime());
                    }

                    if($conversation->getIdUserAffecte() == null) 
                    {
                        $dossierRepository->insertQueueDepartement($conversation->getIdDossier(), $departement, 0, $conversation->getId());
                    }
                }
                
                $respObjects["data"] = "OK";
                $codeStatut = "OK";

            } catch (\Exception $e) {
                $codeStatut = "ERROR";
                $respObjects["err"] = $e->getMessage();
            }
            $respObjects["codeStatut"] = $codeStatut;
            $respObjects["message"] = $this->MessageService->checkMessage($codeStatut);
            return $this->json($respObjects);
        } catch (\Exception $th) {
            $codeStatut = $th->getMessage();
        }

        $respObjects["codeStatut"] = $codeStatut;
        $respObjects["message"] = $this->MessageService->checkMessage($codeStatut);
        return $this->json($respObjects);
    }

    #[Route('/matchConversation/', name: 'matchConversation')]
    public function matchConversation(Request $request, ConversationRepository $conversationRepo,DossierRepository $dossierRepository): Response
    {
        $codeStatut = "ERROR";
        try {
            $respObjects = array();
            $codeStatut = "ERROR";
            try {
                $this->AuthService->checkAuth(0, $request);
                $idUser = $this->AuthService->returnUserId($request);
                $data = json_decode($request->getContent(), true);

                $idDossier = $data["idDossier"];
                $idConversation = $data["idConversation"];

                $conversationRepo->matchConversation(
                    $idDossier, 
                    $idConversation, 
                );

                $conv = $conversationRepo->find($idConversation);
                $doss = $dossierRepository->find($idDossier);

                if($conv != null && $doss != null){

                    if($conv->getIdUserAffecte() == null && $doss->getIdUserAssign() != null){
                        $conversationRepo->assingUser(
                            $doss->getIdUserAssign(),
                            $idConversation, 
                        );
                        $dossierRepository->insertQueueAgent($conv->getIdDossier(), $conv->getIdUserAffecte(), 0, "Conversation ouverte", new \DateTime());
                    }
                }

                
                $respObjects["data"] = "OK";
                $codeStatut = "OK";
            } catch (\Exception $e) {
                $codeStatut = "ERROR";
                $respObjects["err"] = $e->getMessage();
            }
            $respObjects["codeStatut"] = $codeStatut;
            $respObjects["message"] = $this->MessageService->checkMessage($codeStatut);
            return $this->json($respObjects);
        } catch (\Exception $th) {
            $codeStatut = $th->getMessage();
        }

        $respObjects["codeStatut"] = $codeStatut;
        $respObjects["message"] = $this->MessageService->checkMessage($codeStatut);
        return $this->json($respObjects);
    }


    #[Route('/affecteConvertasion/', name: 'affecteConvertasion')]
    public function affecteConvertasion(Request $request, ConversationRepository $conversationRepo,DossierRepository $dossierRepository): Response
    {
        $codeStatut = "ERROR";
        try {
            $respObjects = array();
            $codeStatut = "ERROR";
            try {
                $this->AuthService->checkAuth(0, $request);
                $idUser = $this->AuthService->returnUserId($request);
                $data = json_decode($request->getContent(), true);

                $idConversation = $data["idConversation"];
                $type = $data["type"];
                $idTeam = $data["idTeam"];
                $idUser = $data["idUser"];
                $idQueue = $data["idQueue"];

                if($type == "team")
                {
                    $conversationRepo->assingTeam(
                        $idTeam, 
                        $idQueue, 
                    );    
                }
                else
                {
                    $conversationRepo->assingUser(
                        $idUser, 
                        $idConversation, 
                    );    
                }

                $respObjects["data"] = "OK";
                $codeStatut = "OK";
                
            } catch (\Exception $e) {
                $codeStatut = "ERROR";
                $respObjects["err"] = $e->getMessage();
            }
            $respObjects["codeStatut"] = $codeStatut;
            $respObjects["message"] = $this->MessageService->checkMessage($codeStatut);
            return $this->json($respObjects);
        } catch (\Exception $th) {
            $codeStatut = $th->getMessage();
        }

        $respObjects["codeStatut"] = $codeStatut;
        $respObjects["message"] = $this->MessageService->checkMessage($codeStatut);
        return $this->json($respObjects);
    }

    #[Route('/getQueueDepartement',methods:"GET")]
    public function getQueueDepartement(Request $request,ConversationRepository $conversationRepo): JsonResponse
    {
        $respObjects =array();
        $codeStatut="ERROR";
        try{

            $this->AuthService->checkAuth(0,$request);  

            $idUser = $this->AuthService->returnUserId($request);

            $conversations = $conversationRepo->getQueueDepartement($idUser);
            if($conversations){
                $equipes = $conversationRepo->getDepartementEquipe($idUser);
                $users = $conversationRepo->getUsersOfDepartementTeams($idUser);

                $respObjects["data"] = $conversations;
                $respObjects["equipes"] = $equipes;
                $respObjects["users"] = $users;

                $codeStatut="OK";

            }else{
                $codeStatut = "NOT_EXIST_ELEMENT";
            }
            
        }catch(\Exception $e){
            $codeStatut="ERROR";
            $respObjects["err"] = $e->getMessage();
        }
        $respObjects["codeStatut"] = $codeStatut;
        $respObjects["message"] = $this->MessageService->checkMessage($codeStatut);
        return $this->json($respObjects);
    }
}