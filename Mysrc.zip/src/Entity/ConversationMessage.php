<?php

namespace App\Entity;

use App\Repository\ConversationMessageRepository;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: ConversationMessageRepository::class)]
class ConversationMessage
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(type: Types::TEXT)]
    private ?string $contenu = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE)]
    private ?\DateTimeInterface $date = null;

    #[ORM\Column]
    private ?int $expiteur = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE, nullable: true)]
    private ?\DateTimeInterface $dateFinAttente = null;

    #[ORM\ManyToOne(inversedBy: 'conversationMessages')]
    #[ORM\JoinColumn(nullable: false)]
    private ?Conversation $idConversation = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getContenu(): ?string
    {
        return $this->contenu;
    }

    public function setContenu(string $contenu): static
    {
        $this->contenu = $contenu;

        return $this;
    }

    public function getDate(): ?\DateTimeInterface
    {
        return $this->date;
    }

    public function setDate(\DateTimeInterface $date): static
    {
        $this->date = $date;

        return $this;
    }

    public function getExpiteur(): ?int
    {
        return $this->expiteur;
    }

    public function setExpiteur(int $expiteur): static
    {
        $this->expiteur = $expiteur;

        return $this;
    }

    public function getDateFinAttente(): ?\DateTimeInterface
    {
        return $this->dateFinAttente;
    }

    public function setDateFinAttente(?\DateTimeInterface $dateFinAttente): static
    {
        $this->dateFinAttente = $dateFinAttente;

        return $this;
    }

    public function getIdConversation(): ?Conversation
    {
        return $this->idConversation;
    }

    public function setIdConversation(?Conversation $idConversation): static
    {
        $this->idConversation = $idConversation;

        return $this;
    }
}
