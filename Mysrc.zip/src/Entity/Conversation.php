<?php

namespace App\Entity;

use App\Repository\ConversationRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: ConversationRepository::class)]
class Conversation
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\ManyToOne(inversedBy: 'conversations')]
    private ?Utilisateurs $idCreateur = null;

    #[ORM\ManyToOne(inversedBy: 'conversations')]
    private ?Utilisateurs $idUserAffecte = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE)]
    private ?\DateTimeInterface $dateCreation = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE, nullable: true)]
    private ?\DateTimeInterface $dateDebut = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE, nullable: true)]
    private ?\DateTimeInterface $dateFin = null;

    #[ORM\Column(nullable: true)]
    private ?int $firstReply = null;

    #[ORM\Column(nullable: true)]
    private ?int $reply = null;

    #[ORM\Column(nullable: true)]
    private ?int $timeToEnd = null;

    #[ORM\Column]
    private ?int $type = null;

    #[ORM\Column]
    private ?int $etat = null;

    #[ORM\ManyToOne(inversedBy: 'conversations')]
    private ?Debiteur $idDebiteur = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE, nullable: true)]
    private ?\DateTimeInterface $lastMessage = null;

    #[ORM\ManyToOne(inversedBy: 'conversations')]
    private ?Telephone $idTelephone = null;

    #[ORM\OneToMany(mappedBy: 'idConversation', targetEntity: ConversationMessage::class)]
    private Collection $conversationMessages;

    #[ORM\ManyToOne(inversedBy: 'conversations')]
    private ?Dossier $idDossier = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $Numero = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $resultat = null;

    #[ORM\ManyToOne(inversedBy: 'conversations')]
    private ?ConversationQueue $idQueue = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $numeroTelephone = null;


    public function __construct()
    {
        $this->conversationMessages = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getIdCreateur(): ?Utilisateurs
    {
        return $this->idCreateur;
    }

    public function setIdCreateur(?Utilisateurs $idCreateur): static
    {
        $this->idCreateur = $idCreateur;

        return $this;
    }

    public function getIdUserAffecte(): ?Utilisateurs
    {
        return $this->idUserAffecte;
    }

    public function setIdUserAffecte(?Utilisateurs $idUserAffecte): static
    {
        $this->idUserAffecte = $idUserAffecte;

        return $this;
    }

    public function getDateCreation(): ?\DateTimeInterface
    {
        return $this->dateCreation;
    }

    public function setDateCreation(\DateTimeInterface $dateCreation): static
    {
        $this->dateCreation = $dateCreation;

        return $this;
    }

    public function getDateDebut(): ?\DateTimeInterface
    {
        return $this->dateDebut;
    }

    public function setDateDebut(?\DateTimeInterface $dateDebut): static
    {
        $this->dateDebut = $dateDebut;

        return $this;
    }

    public function getDateFin(): ?\DateTimeInterface
    {
        return $this->dateFin;
    }

    public function setDateFin(?\DateTimeInterface $dateFin): static
    {
        $this->dateFin = $dateFin;

        return $this;
    }

    public function getFirstReply(): ?int
    {
        return $this->firstReply;
    }

    public function setFirstReply(?int $firstReply): static
    {
        $this->firstReply = $firstReply;

        return $this;
    }

    public function getReply(): ?int
    {
        return $this->reply;
    }

    public function setReply(?int $reply): static
    {
        $this->reply = $reply;

        return $this;
    }

    public function getTimeToEnd(): ?int
    {
        return $this->timeToEnd;
    }

    public function setTimeToEnd(?int $timeToEnd): static
    {
        $this->timeToEnd = $timeToEnd;

        return $this;
    }

    public function getType(): ?int
    {
        return $this->type;
    }

    public function setType(int $type): static
    {
        $this->type = $type;

        return $this;
    }

    public function getEtat(): ?int
    {
        return $this->etat;
    }

    public function setEtat(int $etat): static
    {
        $this->etat = $etat;

        return $this;
    }

    public function getIdDebiteur(): ?Debiteur
    {
        return $this->idDebiteur;
    }

    public function setIdDebiteur(?Debiteur $idDebiteur): static
    {
        $this->idDebiteur = $idDebiteur;

        return $this;
    }

    public function getLastMessage(): ?\DateTimeInterface
    {
        return $this->lastMessage;
    }

    public function setLastMessage(?\DateTimeInterface $lastMessage): static
    {
        $this->lastMessage = $lastMessage;

        return $this;
    }

    public function getIdTelephone(): ?Telephone
    {
        return $this->idTelephone;
    }

    public function setIdTelephone(?Telephone $idTelephone): static
    {
        $this->idTelephone = $idTelephone;

        return $this;
    }

    /**
     * @return Collection<int, ConversationMessage>
     */
    public function getConversationMessages(): Collection
    {
        return $this->conversationMessages;
    }

    public function addConversationMessage(ConversationMessage $conversationMessage): static
    {
        if (!$this->conversationMessages->contains($conversationMessage)) {
            $this->conversationMessages->add($conversationMessage);
            $conversationMessage->setIdConversation($this);
        }

        return $this;
    }

    public function removeConversationMessage(ConversationMessage $conversationMessage): static
    {
        if ($this->conversationMessages->removeElement($conversationMessage)) {
            // set the owning side to null (unless already changed)
            if ($conversationMessage->getIdConversation() === $this) {
                $conversationMessage->setIdConversation(null);
            }
        }

        return $this;
    }

    public function getIdDossier(): ?Dossier
    {
        return $this->idDossier;
    }

    public function setIdDossier(?Dossier $idDossier): static
    {
        $this->idDossier = $idDossier;

        return $this;
    }

    public function getNumero(): ?string
    {
        return $this->Numero;
    }

    public function setNumero(string $Numero): static
    {
        $this->Numero = $Numero;

        return $this;
    }

    public function getResultat(): ?string
    {
        return $this->resultat;
    }

    public function setResultat(?string $resultat): static
    {
        $this->resultat = $resultat;

        return $this;
    }

    public function getIdQueue(): ?ConversationQueue
    {
        return $this->idQueue;
    }

    public function setIdQueue(?ConversationQueue $idQueue): static
    {
        $this->idQueue = $idQueue;

        return $this;
    }

    public function getNumeroTelephone(): ?string
    {
        return $this->numeroTelephone;
    }

    public function setNumeroTelephone(?string $numeroTelephone): static
    {
        $this->numeroTelephone = $numeroTelephone;

        return $this;
    }
}
