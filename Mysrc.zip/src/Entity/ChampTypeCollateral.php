<?php

namespace App\Entity;

use App\Repository\ChampTypeCollateralRepository;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: ChampTypeCollateralRepository::class)]
class ChampTypeCollateral
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(nullable: false)]
    private ?TypeCollateral $idType = null;

    #[ORM\Column(length: 255)]
    private ?string $champ = null;

    #[ORM\Column(length: 255)]
    private ?string $value = null;

    #[ORM\ManyToOne(inversedBy: 'champTypeCollaterals')]
    #[ORM\JoinColumn(nullable: false)]
    private ?Collateral $idCollateral = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getIdType(): ?TypeCollateral
    {
        return $this->idType;
    }

    public function setIdType(?TypeCollateral $idType): static
    {
        $this->idType = $idType;

        return $this;
    }

    public function getChamp(): ?string
    {
        return $this->champ;
    }

    public function setChamp(string $champ): static
    {
        $this->champ = $champ;

        return $this;
    }

    public function getValue(): ?string
    {
        return $this->value;
    }

    public function setValue(string $value): static
    {
        $this->value = $value;

        return $this;
    }

    public function getIdCollateral(): ?Collateral
    {
        return $this->idCollateral;
    }

    public function setIdCollateral(?Collateral $idCollateral): static
    {
        $this->idCollateral = $idCollateral;

        return $this;
    }
}
