<?php

namespace App\Entity;

use App\Repository\QueueAgentRepository;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: QueueAgentRepository::class)]
class QueueAgent
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(nullable: false)]
    private ?Dossier $Dossier = null;

    #[ORM\ManyToOne(inversedBy: 'etat')]
    #[ORM\JoinColumn(nullable: false)]
    private ?Utilisateurs $User = null;

    #[ORM\Column]
    private ?int $etat = null;

    #[ORM\Column(length: 1000, nullable: true)]
    private ?string $description = null;

    #[ORM\Column(type: Types::TIME_MUTABLE, nullable: true)]
    private ?\DateTimeInterface $date = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getDossier(): ?Dossier
    {
        return $this->Dossier;
    }

    public function setDossier(?Dossier $Dossier): static
    {
        $this->Dossier = $Dossier;

        return $this;
    }

    public function getUser(): ?Utilisateurs
    {
        return $this->User;
    }

    public function setUser(?Utilisateurs $User): static
    {
        $this->User = $User;

        return $this;
    }

    public function getEtat(): ?int
    {
        return $this->etat;
    }

    public function setEtat(int $etat): static
    {
        $this->etat = $etat;

        return $this;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(?string $description): static
    {
        $this->description = $description;

        return $this;
    }

    public function getDate(): ?\DateTimeInterface
    {
        return $this->date;
    }

    public function setDate(?\DateTimeInterface $date): static
    {
        $this->date = $date;

        return $this;
    }
}
