<?php

namespace App\Entity;

use App\Repository\CollateralCreancesRepository;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: CollateralCreancesRepository::class)]
class CollateralCreances
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\ManyToOne(inversedBy: 'collateralCreances')]
    #[ORM\JoinColumn(nullable: false)]
    private ?Collateral $idCollateral = null;

    #[ORM\ManyToOne(inversedBy: 'collateralCreances')]
    #[ORM\JoinColumn(nullable: false)]
    private ?Creance $idCreance = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getIdCollateral(): ?Collateral
    {
        return $this->idCollateral;
    }

    public function setIdCollateral(?Collateral $idCollateral): static
    {
        $this->idCollateral = $idCollateral;

        return $this;
    }

    public function getIdCreance(): ?Creance
    {
        return $this->idCreance;
    }

    public function setIdCreance(?Creance $idCreance): static
    {
        $this->idCreance = $idCreance;

        return $this;
    }
}
