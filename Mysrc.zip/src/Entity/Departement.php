<?php

namespace App\Entity;

use App\Repository\DepartementRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: DepartementRepository::class)]
class Departement
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    private ?string $nom = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE, nullable: true)]
    private ?\DateTimeInterface $date_creation = null;

    #[ORM\ManyToOne]
    private ?utilisateurs $manager = null;

    // #[ORM\OneToMany(mappedBy: 'assignedDepartement', targetEntity: Task::class)]
    // private Collection $tasks;

    // #[ORM\OneToMany(mappedBy: 'departement', targetEntity: ModelOmniChannel::class)]
    // private Collection $modelOmniChannels;

    public function __construct()
    {
        // $this->tasks = new ArrayCollection();
        // $this->modelOmniChannels = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNom(): ?string
    {
        return $this->nom;
    }

    public function setNom(string $nom): static
    {
        $this->nom = $nom;

        return $this;
    }

    public function getDateCreation(): ?\DateTimeInterface
    {
        return $this->date_creation;
    }

    public function setDateCreation(?\DateTimeInterface $date_creation): static
    {
        $this->date_creation = $date_creation;

        return $this;
    }

    // /**
    //  * @return Collection<int, Task>
    //  */
    // public function getTasks(): Collection
    // {
    //     return $this->tasks;
    // }

    // public function addTask(Task $task): static
    // {
    //     if (!$this->tasks->contains($task)) {
    //         $this->tasks->add($task);
    //         $task->setAssignedDepartement($this);
    //     }

    //     return $this;
    // }

    // public function removeTask(Task $task): static
    // {
    //     if ($this->tasks->removeElement($task)) {
    //         // set the owning side to null (unless already changed)
    //         if ($task->getAssignedDepartement() === $this) {
    //             $task->setAssignedDepartement(null);
    //         }
    //     }

    //     return $this;
    // }

    // /**
    //  * @return Collection<int, ModelOmniChannel>
    //  */
    // public function getModelOmniChannels(): Collection
    // {
    //     return $this->modelOmniChannels;
    // }

    // public function addModelOmniChannel(ModelOmniChannel $modelOmniChannel): static
    // {
    //     if (!$this->modelOmniChannels->contains($modelOmniChannel)) {
    //         $this->modelOmniChannels->add($modelOmniChannel);
    //         $modelOmniChannel->setDepartement($this);
    //     }

    //     return $this;
    // }

    // public function removeModelOmniChannel(ModelOmniChannel $modelOmniChannel): static
    // {
    //     if ($this->modelOmniChannels->removeElement($modelOmniChannel)) {
    //         // set the owning side to null (unless already changed)
    //         if ($modelOmniChannel->getDepartement() === $this) {
    //             $modelOmniChannel->setDepartement(null);
    //         }
    //     }

    //     return $this;
    // }

    public function getManager(): ?utilisateurs
    {
        return $this->manager;
    }

    public function setManager(?utilisateurs $manager): static
    {
        $this->manager = $manager;

        return $this;
    }
}
