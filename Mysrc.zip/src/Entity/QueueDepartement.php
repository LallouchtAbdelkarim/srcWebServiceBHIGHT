<?php

namespace App\Entity;

use App\Repository\QueueDepartementRepository;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: QueueDepartementRepository::class)]
class QueueDepartement
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\ManyToOne]
    private ?Dossier $Dossier = null;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(nullable: false)]
    private ?Departement $Departement = null;

    #[ORM\ManyToOne]
    private ?Teams $Team = null;

    #[ORM\Column]
    private ?int $etat = null;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(nullable: false)]
    private ?Conversation $conversation = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getDossier(): ?Dossier
    {
        return $this->Dossier;
    }

    public function setDossier(?Dossier $Dossier): static
    {
        $this->Dossier = $Dossier;

        return $this;
    }

    public function getDepartement(): ?Departement
    {
        return $this->Departement;
    }

    public function setDepartement(?Departement $Departement): static
    {
        $this->Departement = $Departement;

        return $this;
    }

    public function getTeam(): ?Teams
    {
        return $this->Team;
    }

    public function setTeam(?Teams $Team): static
    {
        $this->Team = $Team;

        return $this;
    }

    public function getEtat(): ?int
    {
        return $this->etat;
    }

    public function setEtat(int $etat): static
    {
        $this->etat = $etat;

        return $this;
    }

    public function getConversation(): ?Conversation
    {
        return $this->conversation;
    }

    public function setConversation(?Conversation $conversation): static
    {
        $this->conversation = $conversation;

        return $this;
    }
}
