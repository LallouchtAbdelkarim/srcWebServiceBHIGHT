<?php

namespace App\Entity;

use App\Repository\TypeCollateralRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: TypeCollateralRepository::class)]
class TypeCollateral
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 1000)]
    private ?string $nom = null;

    #[ORM\OneToMany(mappedBy: 'type', targetEntity: Collateral::class)]
    private Collection $collaterals;

    public function __construct()
    {
        $this->collaterals = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNom(): ?string
    {
        return $this->nom;
    }

    public function setNom(string $nom): static
    {
        $this->nom = $nom;

        return $this;
    }

    /**
     * @return Collection<int, Collateral>
     */
    public function getCollaterals(): Collection
    {
        return $this->collaterals;
    }

    public function addCollateral(Collateral $collateral): static
    {
        if (!$this->collaterals->contains($collateral)) {
            $this->collaterals->add($collateral);
            $collateral->setType($this);
        }

        return $this;
    }

    public function removeCollateral(Collateral $collateral): static
    {
        if ($this->collaterals->removeElement($collateral)) {
            // set the owning side to null (unless already changed)
            if ($collateral->getType() === $this) {
                $collateral->setType(null);
            }
        }

        return $this;
    }
}
