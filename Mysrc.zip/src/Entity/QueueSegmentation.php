<?php

namespace App\Entity;

use App\Repository\QueueSegmentationRepository;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: QueueSegmentationRepository::class)]
class QueueSegmentation
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(nullable: false)]
    private ?Dossier $Dossier = null;

    #[ORM\ManyToOne]
    #[ORM\JoinColumn(nullable: false)]
    private ?Segmentation $segmentation = null;

    #[ORM\Column(nullable: true)]
    private ?int $etat = null;

    #[ORM\Column(nullable: true)]
    private ?int $type = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getDossier(): ?Dossier
    {
        return $this->Dossier;
    }

    public function setDossier(?Dossier $Dossier): static
    {
        $this->Dossier = $Dossier;

        return $this;
    }

    public function getSegmentation(): ?Segmentation
    {
        return $this->segmentation;
    }

    public function setSegmentation(?Segmentation $segmentation): static
    {
        $this->segmentation = $segmentation;

        return $this;
    }

    public function getEtat(): ?int
    {
        return $this->etat;
    }

    public function setEtat(?int $etat): static
    {
        $this->etat = $etat;

        return $this;
    }

    public function getType(): ?int
    {
        return $this->type;
    }

    public function setType(?int $type): static
    {
        $this->type = $type;

        return $this;
    }
}
