<?php

namespace App\Entity;

use App\Repository\CollateralRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: CollateralRepository::class)]
class Collateral
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    private ?string $reference = null;

    #[ORM\ManyToOne(inversedBy: 'collaterals')]
    #[ORM\JoinColumn(nullable: false)]
    private ?TypeCollateral $type = null;

    #[ORM\Column]
    private ?int $status = null;

    #[ORM\Column(type: Types::TEXT, nullable: true)]
    private ?string $description = null;

    #[ORM\Column(nullable: true)]
    private ?float $securedAmount = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $currency = null;

    #[ORM\Column]
    private ?bool $active = null;

    #[ORM\Column(nullable: true)]
    private ?float $marketValue = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE, nullable: true)]
    private ?\DateTimeInterface $valuationDate = null;

    #[ORM\Column(nullable: true)]
    private ?float $seniorLiens = null;

    #[ORM\Column(nullable: true)]
    private ?float $expectedRecovery = null;

    #[ORM\Column(nullable: true)]
    private ?float $ownershipHaircut = null;

    #[ORM\Column(nullable: true)]
    private ?float $equalRankLiens = null;

    #[ORM\Column(nullable: true)]
    private ?float $forcedsalevalue = null;

    #[ORM\Column(nullable: true)]
    private ?float $liquidationCosts = null;

    #[ORM\Column(nullable: true)]
    private ?float $prefferedCreditors = null;

    #[ORM\Column(type: Types::TEXT, nullable: true)]
    private ?string $commentaire = null;

    #[ORM\OneToMany(mappedBy: 'idCollateral', targetEntity: ChampTypeCollateral::class)]
    private Collection $champTypeCollaterals;

    #[ORM\OneToMany(mappedBy: 'idCollateral', targetEntity: CollateralCreances::class)]
    private Collection $collateralCreances;

    #[ORM\OneToMany(mappedBy: 'idCollateral', targetEntity: CollateralDebiteurs::class)]
    private Collection $collateralDebiteurs;

    public function __construct()
    {
        $this->champTypeCollaterals = new ArrayCollection();
        $this->collateralCreances = new ArrayCollection();
        $this->collateralDebiteurs = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getReference(): ?string
    {
        return $this->reference;
    }

    public function setReference(string $reference): static
    {
        $this->reference = $reference;

        return $this;
    }

    public function getType(): ?TypeCollateral
    {
        return $this->type;
    }

    public function setType(?TypeCollateral $type): static
    {
        $this->type = $type;

        return $this;
    }

    public function getStatus(): ?int
    {
        return $this->status;
    }

    public function setStatus(int $status): static
    {
        $this->status = $status;

        return $this;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(?string $description): static
    {
        $this->description = $description;

        return $this;
    }

    public function getSecuredAmount(): ?float
    {
        return $this->securedAmount;
    }

    public function setSecuredAmount(?float $securedAmount): static
    {
        $this->securedAmount = $securedAmount;

        return $this;
    }

    public function getCurrency(): ?string
    {
        return $this->currency;
    }

    public function setCurrency(?string $currency): static
    {
        $this->currency = $currency;

        return $this;
    }

    public function isActive(): ?bool
    {
        return $this->active;
    }

    public function setActive(bool $active): static
    {
        $this->active = $active;

        return $this;
    }

    public function getMarketValue(): ?float
    {
        return $this->marketValue;
    }

    public function setMarketValue(?float $marketValue): static
    {
        $this->marketValue = $marketValue;

        return $this;
    }

    public function getValuationDate(): ?\DateTimeInterface
    {
        return $this->valuationDate;
    }

    public function setValuationDate(?\DateTimeInterface $valuationDate): static
    {
        $this->valuationDate = $valuationDate;

        return $this;
    }

    public function getSeniorLiens(): ?float
    {
        return $this->seniorLiens;
    }

    public function setSeniorLiens(?float $seniorLiens): static
    {
        $this->seniorLiens = $seniorLiens;

        return $this;
    }

    public function getExpectedRecovery(): ?float
    {
        return $this->expectedRecovery;
    }

    public function setExpectedRecovery(?float $expectedRecovery): static
    {
        $this->expectedRecovery = $expectedRecovery;

        return $this;
    }

    public function getOwnershipHaircut(): ?float
    {
        return $this->ownershipHaircut;
    }

    public function setOwnershipHaircut(?float $ownershipHaircut): static
    {
        $this->ownershipHaircut = $ownershipHaircut;

        return $this;
    }

    public function getEqualRankLiens(): ?float
    {
        return $this->equalRankLiens;
    }

    public function setEqualRankLiens(?float $equalRankLiens): static
    {
        $this->equalRankLiens = $equalRankLiens;

        return $this;
    }

    public function getForcedsalevalue(): ?float
    {
        return $this->forcedsalevalue;
    }

    public function setForcedsalevalue(?float $forcedsalevalue): static
    {
        $this->forcedsalevalue = $forcedsalevalue;

        return $this;
    }

    public function getLiquidationCosts(): ?float
    {
        return $this->liquidationCosts;
    }

    public function setLiquidationCosts(?float $liquidationCosts): static
    {
        $this->liquidationCosts = $liquidationCosts;

        return $this;
    }

    public function getPrefferedCreditors(): ?float
    {
        return $this->prefferedCreditors;
    }

    public function setPrefferedCreditors(?float $prefferedCreditors): static
    {
        $this->prefferedCreditors = $prefferedCreditors;

        return $this;
    }

    public function getCommentaire(): ?string
    {
        return $this->commentaire;
    }

    public function setCommentaire(?string $commentaire): static
    {
        $this->commentaire = $commentaire;

        return $this;
    }

    /**
     * @return Collection<int, ChampTypeCollateral>
     */
    public function getChampTypeCollaterals(): Collection
    {
        return $this->champTypeCollaterals;
    }

    public function addChampTypeCollateral(ChampTypeCollateral $champTypeCollateral): static
    {
        if (!$this->champTypeCollaterals->contains($champTypeCollateral)) {
            $this->champTypeCollaterals->add($champTypeCollateral);
            $champTypeCollateral->setIdCollateral($this);
        }

        return $this;
    }

    public function removeChampTypeCollateral(ChampTypeCollateral $champTypeCollateral): static
    {
        if ($this->champTypeCollaterals->removeElement($champTypeCollateral)) {
            // set the owning side to null (unless already changed)
            if ($champTypeCollateral->getIdCollateral() === $this) {
                $champTypeCollateral->setIdCollateral(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection<int, CollateralCreances>
     */
    public function getCollateralCreances(): Collection
    {
        return $this->collateralCreances;
    }

    public function addCollateralCreance(CollateralCreances $collateralCreance): static
    {
        if (!$this->collateralCreances->contains($collateralCreance)) {
            $this->collateralCreances->add($collateralCreance);
            $collateralCreance->setIdCollateral($this);
        }

        return $this;
    }

    public function removeCollateralCreance(CollateralCreances $collateralCreance): static
    {
        if ($this->collateralCreances->removeElement($collateralCreance)) {
            // set the owning side to null (unless already changed)
            if ($collateralCreance->getIdCollateral() === $this) {
                $collateralCreance->setIdCollateral(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection<int, CollateralDebiteurs>
     */
    public function getCollateralDebiteurs(): Collection
    {
        return $this->collateralDebiteurs;
    }

    public function addCollateralDebiteur(CollateralDebiteurs $collateralDebiteur): static
    {
        if (!$this->collateralDebiteurs->contains($collateralDebiteur)) {
            $this->collateralDebiteurs->add($collateralDebiteur);
            $collateralDebiteur->setIdCollateral($this);
        }

        return $this;
    }

    public function removeCollateralDebiteur(CollateralDebiteurs $collateralDebiteur): static
    {
        if ($this->collateralDebiteurs->removeElement($collateralDebiteur)) {
            // set the owning side to null (unless already changed)
            if ($collateralDebiteur->getIdCollateral() === $this) {
                $collateralDebiteur->setIdCollateral(null);
            }
        }

        return $this;
    }
}
