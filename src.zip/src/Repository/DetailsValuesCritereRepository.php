<?php

namespace App\Repository;

use App\Entity\DetailsValuesCritere;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<DetailsValuesCritere>
 *
 * @method DetailsValuesCritere|null find($id, $lockMode = null, $lockVersion = null)
 * @method DetailsValuesCritere|null findOneBy(array $criteria, array $orderBy = null)
 * @method DetailsValuesCritere[]    findAll()
 * @method DetailsValuesCritere[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class DetailsValuesCritereRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, DetailsValuesCritere::class);
    }

    public function save(DetailsValuesCritere $entity, bool $flush = false): void
    {
        $this->getEntityManager()->persist($entity);

        if ($flush) {
            $this->getEntityManager()->flush();
        }
    }

    public function remove(DetailsValuesCritere $entity, bool $flush = false): void
    {
        $this->getEntityManager()->remove($entity);

        if ($flush) {
            $this->getEntityManager()->flush();
        }
    }

//    /**
//     * @return DetailsValuesCritere[] Returns an array of DetailsValuesCritere objects
//     */
//    public function findByExampleField($value): array
//    {
//        return $this->createQueryBuilder('d')
//            ->andWhere('d.exampleField = :val')
//            ->setParameter('val', $value)
//            ->orderBy('d.id', 'ASC')
//            ->setMaxResults(10)
//            ->getQuery()
//            ->getResult()
//        ;
//    }

//    public function findOneBySomeField($value): ?DetailsValuesCritere
//    {
//        return $this->createQueryBuilder('d')
//            ->andWhere('d.exampleField = :val')
//            ->setParameter('val', $value)
//            ->getQuery()
//            ->getOneOrNullResult()
//        ;
//    }
}
